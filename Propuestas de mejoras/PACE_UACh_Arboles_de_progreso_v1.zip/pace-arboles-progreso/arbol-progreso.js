/* PACE UACh · Árbol de progreso · componente sin dependencias · v1.0 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.PaceArbol = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const UNIDADES = Object.freeze({
    U1: { nombre:'Números', cantidades:[4,4,4,2], color:'#3978B9', claro:'#E2EDF9', oscuro:'#24558A', forma:'robusto', tronco:'M166 302 Q188 275 186 226 Q181 174 195 124 Q199 100 210 91 Q221 103 224 127 Q232 173 226 222 Q224 274 249 302 Q228 295 212 302 Q190 295 166 302Z', ramas:[[202,143,160,132,98,93,29,75],[218,142,259,130,324,92,391,75],[195,237,149,232,82,204,28,185],[225,237,268,231,341,207,392,185]] },
    U2: { nombre:'Factorización', cantidades:[3,4,2,3], color:'#8962B5', claro:'#EDE4F6', oscuro:'#64418E', forma:'esbelto', tronco:'M169 302 Q203 264 195 219 Q185 176 203 130 Q211 110 205 87 Q228 98 225 128 Q211 176 226 217 Q232 270 246 302 Q224 293 210 301 Q190 296 169 302Z', ramas:[[206,143,162,128,77,115,30,59],[218,139,273,128,343,82,391,55],[201,237,158,237,80,220,29,184],[226,234,280,245,354,205,391,173]] },
    U3: { nombre:'Ecuaciones lineales y cuadráticas', cantidades:[4,2,4,1], color:'#C59137', claro:'#FBF0D8', oscuro:'#8B601C', forma:'asimétrico', tronco:'M149 302 Q189 270 178 222 Q161 174 180 133 Q192 107 210 94 Q198 128 204 158 Q208 192 219 217 Q227 267 266 302 Q241 293 218 302 Q190 290 149 302Z', ramas:[[185,145,142,139,72,110,27,60],[203,147,251,117,331,104,387,71],[182,230,132,241,73,221,26,193],[218,235,270,232,340,210,380,174]] }
  });
  const HOJAS = Object.freeze({ pendiente:{color:'#C5C5BE',borde:'#92958D'}, en_progreso:{color:'#B5CA80',borde:'#829951'}, completada:{color:'#56964D',borde:'#366B37'} });
  const ESTADOS = Object.keys(HOJAS);
  const ETIQUETAS = {pendiente:'Pendiente',en_progreso:'En progreso',completada:'Completada'};
  const esc = value => String(value).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const round = n => Number(n.toFixed(2));
  function punto(r,t){const a=1-t;return [round(a*a*a*r[0]+3*a*a*t*r[2]+3*a*t*t*r[4]+t*t*t*r[6]),round(a*a*a*r[1]+3*a*a*t*r[3]+3*a*t*t*r[5]+t*t*t*r[7])];}
  function posiciones(r,n){return Array.from({length:n},(_,i)=>punto(r,n===1?.91:.34+.59*i/(n-1)));}
  function normalizar(data){
    if(!data || !Object.hasOwn(UNIDADES,data.unidad)) throw new Error('Unidad desconocida: use U1, U2 o U3.');
    const config=UNIDADES[data.unidad];
    if(!Array.isArray(data.bloques)||data.bloques.length!==4) throw new Error('El diseño actual requiere exactamente cuatro bloques.');
    const ids=new Set(); const blockIds=new Set();
    const bloques=data.bloques.map((b,i)=>{
      if(!b || typeof b.id!=='string'||!b.id||blockIds.has(b.id)) throw new Error('ID de bloque ausente o repetido.');blockIds.add(b.id);
      if(!Array.isArray(b.estaciones)||!b.estaciones.length) throw new Error('Cada bloque debe tener al menos una estación.');
      const estaciones=b.estaciones.map(s=>{
        if(!s||typeof s.id!=='string'||!s.id||ids.has(s.id))throw new Error('ID de estación ausente o repetido.');ids.add(s.id);
        if(!ESTADOS.includes(s.estado))throw new Error('Estado de estación inválido: '+s.estado);
        return {id:s.id,nombre:s.nombre||s.id,estado:s.estado};
      });
      return {id:b.id,nombre:b.nombre||`Bloque ${i+1}`,estaciones};
    });
    const todas=bloques.flatMap(b=>b.estaciones),completadas=todas.filter(s=>s.estado==='completada').length;
    const todasCompletadas=completadas===todas.length;
    return {unidad:data.unidad,config,bloques,total:todas.length,completadas,enProgreso:todas.filter(s=>s.estado==='en_progreso').length,pendientes:todas.filter(s=>s.estado==='pendiente').length,todasCompletadas,finalizada:data.unidadFinalizada===true&&todasCompletadas,inconsistente:data.unidadFinalizada===true&&!todasCompletadas};
  }
  function hoja(estado){
    const h=HOJAS[estado];
    if(estado==='pendiente')return `<path d="M0 -3 Q-9 -12 0 -21 Q9 -12 0 -3Z" fill="${h.color}" stroke="${h.borde}" stroke-width="1.7"/>`;
    if(estado==='en_progreso')return `<path d="M0 -3 C-13 -13 -15 -25 -2 -32 Q10 -19 0 -3Z" fill="${h.color}" stroke="${h.borde}" stroke-width="1.7"/><path d="M0 -3 Q0 -16 11 -22 Q16 -9 0 -3Z" fill="#D1DFA6" stroke="${h.borde}" stroke-width="1.5"/><path d="M0 -5 L-2 -24" stroke="${h.borde}" stroke-width="1.2" fill="none"/>`;
    return `<path d="M0 -3 C-25 -15 -20 -39 9 -43 C24 -21 16 -5 0 -3Z" fill="${h.color}" stroke="${h.borde}" stroke-width="1.8"/><path d="M-14 -19 Q-16 -33 7 -39 Q-7 -27 -14 -19Z" fill="#83B66D" opacity=".8"/><path d="M0 -4 Q5 -21 9 -36 M4 -17 L-8 -25 M7 -25 L15 -28" fill="none" stroke="#D2E6AC" stroke-width="1.5" stroke-linecap="round"/>`;
  }
  function hito(c,fruto){
    if(fruto)return `<path d="M0 -12 Q-2 -20 6 -23" stroke="#795338" stroke-width="2.2" fill="none" stroke-linecap="round"/><path d="M0 -13 C-13 -23 -14 -4 -10 3 Q0 15 10 3 C14 -4 13 -23 0 -13Z" fill="${c.color}" stroke="${c.oscuro}" stroke-width="1.7"/><ellipse cx="-5" cy="-9" rx="3" ry="4" fill="${c.claro}" opacity=".78"/>`;
    return Array.from({length:5},(_,i)=>`<ellipse cx="0" cy="-9" rx="5.7" ry="8.7" transform="rotate(${72*i})" fill="${c.color}" stroke="${c.oscuro}" stroke-width="1"/>`).join('')+`<circle r="5" fill="${c.claro}" stroke="${c.oscuro}" stroke-width="1.2"/>`;
  }
  function crearSVG(data,options={}){
    const m=normalizar(data),c=m.config, animar=new Set(options.animarIds||[]), animarHitos=new Set(options.animarHitos||[]);
    const parts=[`<svg class="pace-arbol__svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 420 320" role="img" aria-label="${esc(`${c.nombre}: ${m.completadas} de ${m.total} estaciones completadas. ${m.finalizada?'Unidad finalizada.':''}`)}"><title>${esc(c.nombre)} · árbol de progreso</title><desc>${esc(m.bloques.map((b,i)=>`Bloque ${i+1}: ${b.estaciones.map(s=>ETIQUETAS[s.estado]).join(', ')}`).join('. '))}</desc>`, `<ellipse cx="210" cy="304" rx="65" ry="6" fill="${c.color}" opacity=".13"/>`];
    c.ramas.forEach((r,i)=>{
      const d=`M${r[0]} ${r[1]} C${r.slice(2).join(' ')}`;
      parts.push(`<g class="pace-arbol__rama" data-bloque="${esc(m.bloques[i].id)}"><path d="${d}" stroke="#795338" stroke-width="15" stroke-linecap="round" fill="none"/><path d="${d}" stroke="#B98554" stroke-width="11" stroke-linecap="round" fill="none"/><path d="${d}" stroke="#E1B17E" stroke-width="2.4" stroke-linecap="round" fill="none" opacity=".7" transform="translate(0 -2)"/></g>`);
    });
    parts.push(`<path d="${c.tronco}" fill="#B98554" stroke="#795338" stroke-width="2.5" stroke-linejoin="round"/><path d="M202 284 Q213 258 205 235 Q199 219 202 200" fill="none" stroke="#E1B17E" stroke-width="4" stroke-linecap="round" opacity=".75"/><path d="M216 285 Q226 269 220 255" fill="none" stroke="#93613E" stroke-width="2.2" stroke-linecap="round"/><path d="M198 276 Q210 262 207 249" fill="none" stroke="${c.color}" stroke-width="3.2" stroke-linecap="round"/>`);
    m.bloques.forEach((b,j)=>{
      const r=c.ramas[j],n=b.estaciones.length,xy=posiciones(r,n),label=punto(r,.14),flower=punto(r,.48),full=b.estaciones.every(s=>s.estado==='completada');
      const scale=Math.min(1,4/n);
      parts.push(`<g class="pace-arbol__numero"><circle cx="${label[0]}" cy="${label[1]+7}" r="11" fill="${c.claro}" stroke="${c.oscuro}" stroke-width="1.3"/><text x="${label[0]}" y="${label[1]+11}" text-anchor="middle" font-size="12" font-weight="700" fill="${c.oscuro}">${j+1}</text></g>`);
      b.estaciones.forEach((s,i)=>{
        const [x,y]=xy[i],angle=j%2===0?-20:17;
        parts.push(`<g class="pace-arbol__estacion" data-estacion="${esc(s.id)}" data-estado="${s.estado}" transform="translate(${x} ${y}) rotate(${angle}) scale(${round(scale)})"><title>${esc(s.nombre)} — ${ETIQUETAS[s.estado]}</title><path d="M0 0 L0 -7" stroke="#795338" stroke-width="2.8" stroke-linecap="round"/><g class="pace-arbol__crecimiento${animar.has(s.id)?' pace-arbol__crecimiento--animar':''}">${hoja(s.estado)}</g></g>`);
      });
      if(full){const type=m.finalizada?'fruto':'flor';parts.push(`<g class="pace-arbol__hito" data-hito="${type}" data-bloque="${esc(b.id)}" transform="translate(${flower[0]} ${flower[1]+20})"><title>${m.finalizada?'Unidad finalizada: fruto':'Todas las estaciones del bloque completadas: flor'}</title><path d="M0 -19 L0 -10" stroke="#795338" stroke-width="2"/><g class="pace-arbol__crecimiento${animarHitos.has(b.id)?' pace-arbol__crecimiento--animar':''}">${hito(c,m.finalizada)}</g></g>`);}
    });
    return parts.join('')+'</svg>';
  }
  function montar(container,data,options={}){
    if(!container||typeof container.replaceChildren!=='function')throw new Error('Contenedor DOM requerido.');
    let prev=null,actual=null;
    function actualizar(next,{animar=true}={}){
      const m=normalizar(next),ids=[],hitos=[];
      if(animar&&prev&&prev.unidad===m.unidad){const old=new Map(prev.bloques.flatMap(b=>b.estaciones).map(s=>[s.id,s.estado]));m.bloques.forEach(b=>{b.estaciones.forEach(s=>{if(old.has(s.id)&&old.get(s.id)!==s.estado&&s.estado!=='pendiente')ids.push(s.id);});const before=prev.bloques.find(x=>x.id===b.id);if(b.estaciones.every(s=>s.estado==='completada')&&(!before||!before.estaciones.every(s=>s.estado==='completada')||prev.finalizada!==m.finalizada))hitos.push(b.id);});}
      const svg=crearSVG(next,{animarIds:ids,animarHitos:hitos});
      const doc=container.ownerDocument,template=doc.createElement('template');template.innerHTML=svg;
      const wrapper=doc.createElement('div');wrapper.className='pace-arbol';wrapper.style.setProperty('--pace-unidad',m.config.color);wrapper.append(template.content);
      if(options.resumen!==false){const p=doc.createElement('p');p.className='pace-arbol__resumen';p.textContent=`${m.completadas} de ${m.total} estaciones completadas`;wrapper.append(p);const status=doc.createElement('p');status.className='pace-arbol__estado';status.textContent=m.finalizada?'Unidad finalizada':m.todasCompletadas?'Todas las estaciones completadas · falta finalizar la unidad':`${m.enProgreso} en progreso · ${m.pendientes} pendientes`;wrapper.append(status);}
      container.replaceChildren(wrapper);prev=m;actual=m;
      return m;
    }
    actualizar(data,{animar:false});
    return {actualizar,obtenerResumen:()=>({unidad:actual.unidad,total:actual.total,completadas:actual.completadas,enProgreso:actual.enProgreso,pendientes:actual.pendientes,todasCompletadas:actual.todasCompletadas,finalizada:actual.finalizada,inconsistente:actual.inconsistente}),destruir:()=>{container.replaceChildren();prev=null;actual=null;}};
  }
  function datosDemo(unidad){const c=UNIDADES[unidad];return {unidad,unidadFinalizada:false,bloques:c.cantidades.map((n,i)=>({id:`${unidad}-b${i+1}`,nombre:`Bloque ${i+1}`,estaciones:Array.from({length:n},(_,j)=>({id:`${unidad}-b${i+1}-e${j+1}`,nombre:`Bloque ${i+1}, estación ${j+1}`,estado:'pendiente'}))}))};}
  return {UNIDADES,HOJAS,ESTADOS,ETIQUETAS,normalizar,crearSVG,montar,datosDemo};
});
