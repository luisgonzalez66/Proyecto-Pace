'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),P=require('../arbol-progreso.js');
const expected={U1:[4,4,4,2],U2:[3,4,2,3],U3:[4,2,4,1]};
const count=(s,pattern)=>(s.match(pattern)||[]).length;
for(const [id,counts] of Object.entries(expected)){
  test(`${id}: estructura, estados e hitos`,()=>{
    const d=P.datosDemo(id), total=counts.reduce((a,b)=>a+b,0);
    assert.deepEqual(d.bloques.map(b=>b.estaciones.length),counts);
    const start=P.crearSVG(d);
    assert.equal(count(start,/class="pace-arbol__rama"/g),4);
    assert.equal(count(start,/data-estacion=/g),total);
    assert.equal(count(start,/data-estado="pendiente"/g),total);
    assert.equal(count(start,/data-hito=/g),0);
    d.bloques[0].estaciones[0].estado='en_progreso';
    assert.equal(P.normalizar(d).enProgreso,1);
    assert.equal(count(P.crearSVG(d),/data-estado="en_progreso"/g),1);
    d.bloques[0].estaciones.forEach(s=>s.estado='completada');
    assert.equal(count(P.crearSVG(d),/data-hito="flor"/g),1);
    d.unidadFinalizada=true;
    assert.equal(P.normalizar(d).inconsistente,true);
    assert.equal(count(P.crearSVG(d),/data-hito="fruto"/g),0);
    d.unidadFinalizada=false;
    d.bloques.flatMap(b=>b.estaciones).forEach(s=>s.estado='completada');
    const snapshot=JSON.stringify(d),flowers=P.crearSVG(d);
    assert.equal(count(flowers,/data-hito="flor"/g),4);
    assert.equal(count(flowers,/data-hito="fruto"/g),0);
    assert.equal(P.normalizar(d).completadas,total);
    assert.equal(JSON.stringify(d),snapshot);
    d.unidadFinalizada=true;
    const fruits=P.crearSVG(d);
    assert.equal(count(fruits,/data-hito="fruto"/g),4);
    assert.equal(count(fruits,/data-hito="flor"/g),0);
    const anchors=x=>[...x.matchAll(/data-estacion="([^"]+)" data-estado="[^"]+" transform="([^"]+)"/g)].map(v=>[v[1],v[2]]);
    assert.deepEqual(anchors(start),anchors(fruits));
  });
}
test('Adapta el número real de estaciones dentro de cuatro bloques',()=>{const d=P.datosDemo('U1');d.bloques[0].estaciones.push({id:'nueva',estado:'pendiente'});assert.equal(count(P.crearSVG(d),/data-estacion=/g),15);});
test('Rechaza estados e identificadores inválidos y escapa etiquetas',()=>{const d=P.datosDemo('U1');d.bloques[0].estaciones[0].estado='otro';assert.throws(()=>P.crearSVG(d));d.bloques[0].estaciones[0].estado='pendiente';d.bloques[0].estaciones[0].nombre='<script>alert(1)</script>';assert.ok(!P.crearSVG(d).includes('<script>'));d.bloques[0].estaciones[1].id=d.bloques[0].estaciones[0].id;assert.throws(()=>P.crearSVG(d));});
