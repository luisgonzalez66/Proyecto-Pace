/* Controlador de demostración: no incorporar al curso estudiantil. */
(function(){
  const P=window.PaceArbol, ids=Object.keys(P.UNIDADES), states=Object.fromEntries(ids.map(id=>[id,P.datosDemo(id)]));
  let selected='U1';const $=id=>document.getElementById(id);const mini={};
  const tree=P.montar($('tree'),states[selected]);
  ids.forEach((id,i)=>{const tab=document.createElement('button');tab.textContent=`Unidad ${['I','II','III'][i]}`;tab.dataset.unit=id;tab.style.setProperty('--active',P.UNIDADES[id].color);tab.onclick=()=>{selected=id;refresh(false);};$('tabs').append(tab);const card=document.createElement('article');card.className='mini';const title=document.createElement('h3');title.textContent=`Unidad ${['I','II','III'][i]}`;title.style.color=P.UNIDADES[id].oscuro;const el=document.createElement('div');card.append(title,el);$('overview').append(card);mini[id]=P.montar(el,states[id]);});
  function refresh(animate=true,message=''){
    const d=states[selected], m=tree.actualizar(d,{animar:animate});
    mini[selected].actualizar(d,{animar:animate});
    [...$('tabs').children].forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.unit===selected)));
    $('official').checked=d.unidadFinalizada;$('official').disabled=!m.todasCompletadas;
    $('controls').replaceChildren();d.bloques.forEach((b,i)=>{const block=document.createElement('div');block.className='block';const title=document.createElement('div');title.className='block-title';title.textContent=`Bloque ${i+1} · ${b.estaciones.filter(s=>s.estado==='completada').length}/${b.estaciones.length}`;const list=document.createElement('div');list.className='station-list';b.estaciones.forEach((s,j)=>{const btn=document.createElement('button');btn.className='station';btn.dataset.state=s.estado;btn.dataset.id=s.id;btn.setAttribute('aria-label',`Bloque ${i+1}, estación ${j+1}: ${P.ETIQUETAS[s.estado]}. Cambiar estado`);const strong=document.createElement('b');strong.textContent=`E${j+1}`;btn.append(strong,document.createTextNode(P.ETIQUETAS[s.estado]));btn.onclick=()=>{const before=b.estaciones.every(v=>v.estado==='completada');s.estado=P.ESTADOS[(P.ESTADOS.indexOf(s.estado)+1)%3];if(s.estado!=='completada')d.unidadFinalizada=false;const full=b.estaciones.every(v=>v.estado==='completada');refresh(true,!before&&full?'¡Todas las estaciones del bloque completadas!':s.estado==='completada'?'¡Una nueva estación completada!':'');[...$('controls').querySelectorAll('button')].find(x=>x.dataset.id===s.id)?.focus();};list.append(btn);});block.append(title,list);$('controls').append(block);});
    $('feedback').textContent=message;
  }
  function preset(kind){const d=states[selected];d.unidadFinalizada=false;d.bloques.forEach((b,i)=>b.estaciones.forEach((s,j)=>s.estado=kind==='all'?'completada':kind==='partial'?(i===0?'completada':i===1?(j===0?'completada':j===1?'en_progreso':'pendiente'):i===2&&j===0?'en_progreso':'pendiente'):'pendiente'));refresh(true,kind==='all'?'¡Todas las estaciones completadas!':'');}
  $('initial').onclick=()=>preset('initial');$('partial').onclick=()=>preset('partial');$('all').onclick=()=>preset('all');$('official').onchange=e=>{states[selected].unidadFinalizada=e.target.checked;refresh(true,e.target.checked?'¡Has completado la unidad!':'');};refresh(false);
})();
