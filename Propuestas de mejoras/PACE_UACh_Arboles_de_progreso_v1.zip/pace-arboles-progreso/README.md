# Árboles de progreso · PACE UACh

**Versión 1.0 · Prototipo funcional para integración · 24 de noviembre de 2026**

Hola Luis: proponemos incorporar un árbol dinámico por unidad para mostrar el avance de las estaciones, complementando al Chucao. Este paquete contiene un componente listo para adaptar al motor del curso, no una modificación del repositorio existente. No requiere imágenes de estados, librerías externas, servidor, ni conexión a internet.

## 1. Cómo probarlo

1. Descomprimir el ZIP.
2. Abrir `demo-autonoma.html` en un navegador. Es un HTML autocontenido: también puede abrirse por separado.
3. Seleccionar U1, U2 o U3. Probar los botones de simulación, o pulsar cada estación para alternar entre pendiente, en progreso y completada.
4. Completar todas las estaciones y observar las cuatro flores. Marcar la unidad como finalizada oficialmente y observar cómo las flores se transforman en frutos.
5. Reducir el ancho de la ventana para ver el comportamiento móvil. Al final de la página aparecen las miniaturas de las tres unidades, vinculadas a los mismos datos de la demo.

`index.html` reproduce la misma demostración, pero carga los archivos fuente separados. **No incorporar `demo.js`, los controles de simulación ni el reinicio de demostración a la versión estudiantil.** En el curso real el estudiante jamás debe poder modificar o reiniciar su progreso mediante el árbol.

## 2. Reglas visuales y académicas

| Unidad | Bloque 1 | Bloque 2 | Bloque 3 | Bloque 4 | Total |
|---|---:|---:|---:|---:|---:|
| I — Números | 4 | 4 | 4 | 2 | 14 |
| II — Factorización | 3 | 4 | 2 | 3 | 12 |
| III — Ecuaciones lineales y cuadráticas | 4 | 2 | 4 | 1 | 11 |

- Tronco = unidad; cuatro ramas principales = bloques numerados; una posición de hoja = una estación.
- Orden fijo de bloques: superior izquierda (1), superior derecha (2), inferior izquierda (3), inferior derecha (4). En cada rama, las posiciones van desde el tronco hacia la punta.
- El árbol comienza sin follaje desarrollado. No hay hojas, flores ni frutos decorativos. El brote neutro muestra la posición de una estación pendiente.
- Los tres árboles comparten estilo vectorial cartoon 2D simplificado y fondo transparente, pero tienen siluetas distintas: U1 robusto y equilibrado, U2 esbelto y curvado, U3 asimétrico. El diseño evita texturas finas para conservar legibilidad móvil.
- Las posiciones no cambian con el avance; solo cambia la forma de cada hoja. La identidad cromática de la unidad se aprecia en los números de rama, un detalle del tronco y los hitos.
- **Floración:** cuando todas las estaciones de un bloque están completadas, aparece exactamente una flor del color de la unidad en su rama. Esto indica el fin de sus estaciones, no necesariamente la entrega del Cierre de bloque.
- **Fructificación:** al finalizar oficialmente la unidad, las cuatro flores se sustituyen por cuatro frutos del mismo color de identidad. No se añade follaje adicional.
- Tener todas las estaciones completadas no equivale necesariamente a haber terminado la unidad. La señal de finalización oficial proviene del motor existente, con la Meta final y cualquier otro requisito que se haya acordado. Este componente no define nuevos requisitos.
- Si el motor informa que la unidad está finalizada pero aún hay estaciones incompletas, el componente no muestra frutos y devuelve `inconsistente: true`. Se debe revisar esa discrepancia en el adaptador, sin modificar automáticamente el registro del estudiante. Se adopta esta regla defensiva porque la propuesta presupone cuatro ramas florecidas antes de fructificar; confirmar que coincide con la lógica académica definitiva.
- La animación de crecimiento dura 550 ms y solo se activa en cambios detectados desde la última actualización de esa instancia. Al recuperar el progreso al iniciar o recargar, no se reproducen las celebraciones antiguas. Respeta `prefers-reduced-motion`.

### Paleta acordada

| Unidad | Principal | Claro | Oscuro |
|---|---|---|---|
| I — Azul | `#3978B9` | `#E2EDF9` | `#24558A` |
| II — Violeta | `#8962B5` | `#EDE4F6` | `#64418E` |
| III — Ocre dorado | `#C59137` | `#FBF0D8` | `#8B601C` |

| Estado | Forma | Relleno | Borde |
|---|---|---|---|
| Pendiente | Brote cerrado, pequeño | `#C5C5BE` | `#92958D` |
| En progreso | Hoja pequeña parcialmente abierta | `#B5CA80` | `#829951` |
| Completada | Hoja grande abierta, con nervaduras | `#56964D` | `#366B37` |

Los estados se distinguen por forma, tamaño y color. El rojo y el verde no son colores identificadores de unidades. El verde se usa en el crecimiento y la finalización, de forma coherente con su significado positivo. Madera en tonos naturales; flores de cinco pétalos y frutos redondeados en la paleta propia de cada unidad.

## 3. Integración con HTML, CSS y JavaScript existentes

Copiar únicamente `arbol-progreso.js` y `arbol-progreso.css` a la carpeta de recursos del proyecto. Cargarlos en la plantilla o empaquetarlos con el constructor existente:

```html
<link rel="stylesheet" href="arbol-progreso.css">
<div id="arbol-unidad"></div>
<script src="arbol-progreso.js"></script>
```

El componente se expone como `window.PaceArbol`. La API recibe un objeto con la estructura real de la unidad y sus estados, por ejemplo (fragmento esquemático):

```js
const datos = {
  unidad: 'U1',
  unidadFinalizada: false, // dato académico real del motor
  bloques: [
    { id: 'id-bloque-1', nombre: 'Nombre real del bloque', estaciones: [
      { id: 'id-estacion-1', nombre: 'Nombre real', estado: 'completada' },
      { id: 'id-estacion-2', nombre: 'Nombre real', estado: 'en_progreso' },
      { id: 'id-estacion-3', nombre: 'Nombre real', estado: 'pendiente' },
      { id: 'id-estacion-4', nombre: 'Nombre real', estado: 'pendiente' }
    ] },
    // Añadir los otros tres bloques con sus estaciones reales.
  ]
};
// Cuando el objeto esté completo:
const arbol = PaceArbol.montar(document.getElementById('arbol-unidad'), datos);
// Después de guardar o restaurar el avance real:
// arbol.actualizar(nuevosDatos);
```

El ejemplo anterior es ilustrativo; para una ejecución inmediata usar `PaceArbol.datosDemo('U1')` solamente en pruebas. La API valida que existan cuatro bloques con identificadores únicos de bloque y estación, al menos una estación por bloque, y estados válidos. Lee el número de estaciones que recibe, no rellena con hojas ficticias. El diseño actual está optimizado para 1–4 estaciones por rama; si crece mucho el número, habrá que revisar el espaciado móvil. Una futura unidad con un número distinto de cuatro bloques requerirá ampliar su geometría.

### Conectar la fuente de verdad

1. Construir un adaptador que lea la estructura de cada unidad desde su JSON y el avance real que ya guarda el motor (incluido SCORM si corresponde).
2. Mapear los estados reales a `pendiente`, `en_progreso` o `completada`. No recalcular ni inventar los criterios de Aprende, Practica, Aplica y Explora. Explora es opcional y no debería introducir por sí solo una condición nueva para completar una estación.
3. Montar el árbol al abrir la ventana de una unidad, después de recuperar el avance. Tras guardar un cambio real, llamar a `actualizar(datos)`; al restaurar un estado, usar `actualizar(datos, {animar:false})`. Usar identificadores estables de las estaciones, no los índices como clave de persistencia.
4. Para las miniaturas en «Todas las unidades», montar otra instancia por unidad usando esos mismos datos. Actualizar ambas vistas tras un cambio, si están montadas. Las instancias no se sincronizan solas: es responsabilidad del motor enviar el mismo estado a cada vista.
5. No guardar datos adicionales por el árbol: no escribe en localStorage, no llama a APIs SCORM, no añade contadores ni modifica el progreso. `montar` solo conserva temporalmente la representación anterior para detectar animaciones.

### API pública

- `PaceArbol.montar(elemento, datos, {resumen: true})`: crea una instancia y dibuja sin animación inicial. Con `resumen:false` omite el texto debajo del SVG.
- `instancia.actualizar(datos, {animar:true})`: vuelve a dibujar y anima los cambios nuevos. Devuelve el modelo normalizado. No muta los datos recibidos.
- `instancia.obtenerResumen()`: devuelve total, completadas, pendientes, enProgreso, todasCompletadas, finalizada e inconsistente.
- `instancia.destruir()`: elimina el contenido del contenedor. Crear una nueva instancia si se vuelve a abrir la vista.
- `PaceArbol.crearSVG(datos)`: devuelve el SVG como texto, útil para otras plantillas. `PaceArbol.normalizar(datos)` valida y resume sin acceder al DOM.
- `PaceArbol.UNIDADES`, `HOJAS`, `ESTADOS` y `ETIQUETAS`: configuración común. `datosDemo` solo para pruebas.

## 4. Ubicación y relación con el Chucao

**Ventana de unidad:** `Chucao | Árbol`. Ambos módulos separados, de peso visual similar. En un ancho reducido, apilarlos en lugar de comprimir el árbol hasta hacerlo ilegible; la ilustración admite un ancho máximo de 440 px, ajustable por la plantilla. No mostrar el árbol dentro de las estaciones. El Chucao sí sigue acompañando al estudiante allí.

**Todas las unidades:** Chucao, racha diaria y porcentaje global en el espacio superior; un árbol compacto en cada tarjeta de unidad, junto con su recuento de estaciones. En móviles, priorizar el texto si el tamaño de la miniatura es muy reducido.

**Chucao:** su evolución depende del avance global del curso, no del árbol de la unidad. Los árboles informan el avance local. El motor existente debe emitir las reacciones del Chucao a los mismos cambios académicos: «¡Una nueva estación completada!», «¡Bloque completado!» (según el criterio real de bloque), «¡Has completado la unidad!». No repetir estas celebraciones al cargar un estado antiguo o repetir una actividad completada. Si solo se completaron las estaciones pero falta el Cierre de bloque, preferir «¡Todas las estaciones del bloque completadas!».

La demo muestra mensajes de ejemplo, no incluye los recursos ni la lógica del Chucao. La conexión de sus reacciones al motor queda pendiente.

## 5. Archivos y comprobaciones

- `demo-autonoma.html`: demo completa en un único archivo (derivada de los fuentes).
- `index.html`, `demo.js`: demo modular (solo pruebas).
- `arbol-progreso.js`, `arbol-progreso.css`: componente de producción.
- `tests/arbol.test.js`: pruebas sin dependencias externas. Ejecutar `node --test tests/arbol.test.js` (Node 22 probado).
- `tests/resultado-node.txt`: resultado de pruebas unitarias.
- `tests/resultado-navegador.txt`: resultado de pruebas de interacción en Chromium.

Pendientes de integración: comprobar las estructuras y nombres reales del JSON, el contrato de progreso y los requisitos oficiales de finalización; validar la interfaz junto al Chucao; probar la versión exportada HTML y SCORM en SIVEDUCMD, incluidos recuperación de avance, navegación y móvil real. El paquete no altera ni publica el repositorio GitHub. No requiere generar imágenes combinatorias ni un sistema adicional de persistencia.
