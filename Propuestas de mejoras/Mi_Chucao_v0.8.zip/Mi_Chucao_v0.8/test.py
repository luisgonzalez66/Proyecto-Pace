from pathlib import Path
from playwright.sync_api import sync_playwright
p=Path(__file__).resolve().parent
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for w,h in [(1280,850),(390,780)]:
  pg=b.new_page(viewport={'width':w,'height':h});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
  pg.set_content((p/'demo-autonoma.html').read_text(),timeout=20000)
  assert pg.evaluate('demoChucao.stage')==1
  for i in range(1,6):
   pg.locator(f'#stages [data-key="{i}"]').click()
   assert pg.evaluate('demoChucao.stage')==i
   assert pg.locator('[data-part=eggScene]').get_attribute('display')==('inline' if i==1 else 'none')
   assert pg.locator('[data-part=shell]').get_attribute('display')==('inline' if i==2 else 'none')
   for pose in ['aprende','practica','aplica','explora']:
    pg.evaluate(f"demoChucao.setSection('{pose}')")
    assert pg.evaluate('demoChucao.section')==pose
    assert pg.evaluate("demoChucao.react('saludo')")
   for reaction in ['correcta','pensar','celebrar','guiño','explicar']:
    assert pg.evaluate(f"demoChucao.react('{reaction}')")
   if w==1280:
    pg.evaluate("demoChucao.setSection('aprende');demoChucao.setPaused(true)")
    pg.locator('#scene').screenshot(path=f'/tmp/chucao08-{i}.png')
    pg.evaluate('demoChucao.setPaused(false)')
  pg.locator('#openEconomy').click()
  pg.locator('#firstStation').check()
  assert pg.locator('#lightBalance').inner_text()=='2'
  pg.locator('#evolve').click()
  assert pg.evaluate('demoChucao.stage')==2
  pg.locator('#openEconomy').click()
  pg.locator('#officialEnd').check()
  for stage in [3,4,5]:
   pg.locator('#evolve').click()
   assert pg.evaluate('demoChucao.stage')==stage
   pg.locator('#openEconomy').click()
  assert pg.locator('#lightBalance').inner_text()=='0'
  pg.locator('#exerciseCount').fill('25');pg.locator('#addSeeds').click()
  assert pg.locator('#normalBalance').inner_text()=='25'
  pg.locator('#buyExample').click()
  assert pg.locator('#normalBalance').inner_text()=='5'
  assert pg.locator('#buyExample').is_disabled()
  pg.locator('#closeEconomy').click()
  assert pg.evaluate('document.documentElement.scrollWidth<=innerWidth')
  assert not errs,errs
  if w==1280: pg.screenshot(path=str(p/'ubicacion-semillas-demo.png'),full_page=True)
  print(f'{w}x{h}: etapas, poses, reacciones, cuatro evoluciones, canje de prueba y saldos OK',flush=True)
  pg.close()
 b.close()
