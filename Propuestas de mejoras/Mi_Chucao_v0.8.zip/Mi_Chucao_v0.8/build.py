from pathlib import Path
import base64,json
p=Path(__file__).resolve().parent
s=(p/'index.html').read_text(encoding='utf-8')
a={x.stem:'data:'+('image/svg+xml' if x.suffix=='.svg' else 'image/webp')+';base64,'+base64.b64encode(x.read_bytes()).decode() for x in (p/'assets').iterdir() if x.suffix in ('.svg','.webp') and x.stem!='reference-front'}
s=s.replace('<link rel="stylesheet" href="chucao.css">','<style>'+ (p/'chucao.css').read_text()+'</style>')
s=s.replace('<script src="chucao.js"></script>','<script>window.CHUCAO_ASSETS='+json.dumps(a)+';\n'+(p/'chucao.js').read_text()+'</script>').replace('<script src="demo.js"></script>','<script>'+(p/'demo.js').read_text()+'</script>')
(p/'demo-autonoma.html').write_text(s,encoding='utf-8')
