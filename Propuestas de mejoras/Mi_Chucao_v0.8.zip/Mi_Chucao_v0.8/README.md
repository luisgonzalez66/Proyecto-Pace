# Mi Chucao · Cinco etapas · v0.8

## Abrir
`demo-autonoma.html` funciona sin conexión y no requiere instalación. `index.html` utiliza los recursos separados. `build.py` reconstruye el HTML autónomo con Python estándar.

## Cambios
- I: huevo intacto animado; objetos APAE a su lado; grietas cuando la eclosión está disponible.
- II: polluelo en el cascarón, alitas reducidas y accesorios de cabeza.
- III: polluelo pequeño sin cola visible.
- IV y V: misma contextura relativa, crecimiento del penacho, la cola y las garras; puntas del penacho discretamente doradas. Se mantiene el naranja original del pecho.
- Se agregó plumaje lateral bajo las alas y se retiró el relleno liso del torso. Las ilustraciones se derivan de las anteriores mediante ediciones localizadas. Las articulaciones y superposiciones deben seguir evaluándose visualmente.
- Conserva cuatro secciones APAE, siete accesorios, seis reacciones, cinco entornos y tronco fijo.

## Demostración de semillas
Los dos saldos aparecen encima de la escena. «Probar semillas» abre un simulador en memoria; la etapa efectiva es independiente de la previsualización libre. Se puede simular avance, registrar la primera estación o finalización oficial, activar las cuatro evoluciones en orden (2, 13, 35, 50 semillas de luz), registrar respuestas nuevas y probar un canje de anteojos de 20 semillas normales. No existe tienda completa ni persistencia real. Los accesorios de la vista de prueba son libres, no constituyen inventario. No trasladar los controles de simulación ni reinicio al curso estudiantil.

## Archivos
- Propuesta_semillas_y_personalizacion.txt: especificación académica y funcional, precios ilustrativos pendientes de calibración.
- assets/semilla.svg, assets/semilla-luz.svg y sus PNG transparentes: iconos independientes.
- ubicacion-semillas-demo.png: captura de la barra de saldos en el prototipo.
- etapas-preview.jpg: comparación de las cinco etapas.
- chucao.js, chucao.css, demo.js, assets/: fuente.
- test.py, validation.txt: comprobaciones de Chromium.

## Integración
`Chucao.create(container,{stage:1,assets,onReactionEnd})` devuelve `setStage(1..5)`, `setSection('aprende'|'practica'|'aplica'|'explora')`, `setAccessories([...])`, `setEvolutionReady(boolean)`, `react(...)`, `setPaused(boolean)` y `destroy()`, además de las propiedades stage, section, accessories, paused. `ChucaoIII` es un alias de compatibilidad. La tienda, la persistencia, la exportación PNG personalizada y la conexión a SCORM están pendientes. En producción usar el registro académico como única fuente del avance; no usar los saldos de la demo. Los iconos no requieren recursos externos.

Pruebas en Chromium mediante HTML embebido, resoluciones de escritorio y móvil simuladas; no en dispositivos físicos ni SIVEDUCMD.
